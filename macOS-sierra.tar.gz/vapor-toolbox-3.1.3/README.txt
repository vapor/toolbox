Manual Install Instructions for Vapor Toolbox v3.1.3

- Move *.dylib files into /usr/local/lib
- Move executable vapor into /usr/local/bin
- Type 'vapor --help' into terminal to verify installation
